/**
 * Copyright 2013-present, Facebook, Inc.
 * All rights reserved.
 *
 * This source code is licensed under the BSD-style license found in the
 * LICENSE file in the root directory of this source tree. An additional grant
 * of patent rights can be found in the PATENTS file in the same directory.
 *
 * @providesModule Danger
 */

'use strict';

var DOMLazyTree = require('DOMLazyTree');
var ExecutionEnvironment = require('ExecutionEnvironment');

var createNodesFromMarkup = require('createNodesFromMarkup');
var emptyFunction = require('emptyFunction');
var invariant = require('invariant');

var Danger = {
  /**
   * Replaces a node with a string of markup at its current position within its
   * parent. The markup must render into a single root node.
   *
   * @param {DOMElement} oldChild Child node to replace.
   * @param {string} markup Markup to render in place of the child node.
   * @internal
   */
  dangerouslyReplaceNodeWithMarkup: function(oldChild, markup) {
    invariant(
      ExecutionEnvironment.canUseDOM,
      'dangerouslyReplaceNodeWithMarkup(...): Cannot render markup in a ' +
        'worker thread. Make sure `window` and `document` are available ' +
        'globally before requiring React when unit testing or use ' +
        'ReactDOMServer.renderToString() for server rendering.',
    );
    invariant(markup, 'dangerouslyReplaceNodeWithMarkup(...): Missing markup.');
    invariant(
      oldChild.nodeName !== 'HTML',
      'dangerouslyReplaceNodeWithMarkup(...): Cannot replace markup of the ' +
        '<html> node. This is because browser quirks make this unreliable ' +
        'and/or slow. If you want to render to the root you must use ' +
        'server rendering. See ReactDOMServer.renderToString().',
    );

    if (typeof markup === 'string') {
      var newChild = createNodesFromMarkup(markup, emptyFunction)[0];
      oldChild.parentNode.replaceChild(newChild, oldChild);
    } else {
      DOMLazyTree.replaceChildWithTree(oldChild, markup);
    }
  },
};

module.exports = Danger;
